const eventTemplate = `
    <h2>Event details:</h2>
    <table class="table table-striped" id="Event-show">
        <tbody>
        <tr>
            <td>Raspberry Pi Number</td>
            <td>{{raspberryPiNo}}</td>
        </tr>
        <tr>
            <td>Event Type</td>
            <td>{{EventType}}</td>
        </tr>
        <tr>
            <td>Label</td>
            <td>{{Label}}</td>
        </tr>
        <tr>
            <td>Location</td>
            <td>{{Location}}</td>
        </tr>
        <tr>
            <td>Date</td>
            <td>{{Date}}</td>
        </tr>
        <tr>
            <td>Time</td>
            <td>{{Time}}</td>
        </tr>
    </tbody>
</table>`




async function displayEvent(raspberryPiNo) {
    console.log("displayEvent.raspberryPiNo: ", raspberryPiNo)

    try {
        const event = await fetchEvent(raspberryPiNo)
        console.log(event)


        let htmlTemplate = Handlebars.compile(eventTemplate)

        document.querySelector('#event-details').innerHTML = htmlTemplate(event)
    }
    catch (err) {
        console.log(err)
    }
}
