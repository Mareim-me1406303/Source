class EventController {
    constructor() {
        this.EventRepository = require('./../models/EventRepository')
    }

    async index (req, res) {
        const events = await this.EventRepository.getEvents()

        res.render('events', {events})
    }


}
module.exports = new EventController()