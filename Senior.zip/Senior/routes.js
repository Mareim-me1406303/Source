let express = require('express')
let router = express.Router()
const fs = require("fs-promise")

let EventController = require('./controllers/EventController')
//Routes returning views
router.get('/', (req, res) => res.render('index') )

router.route('/login')
    .get( (req, res) => res.sendFile(__dirname + "/views/login.html") )
    .post( (req, res) => {
        let userInfo = req.body
        console.log("router.post.req.body", userInfo)

        //Return an accessCount cookie to the client -- expires is optional
        const duration24H = 24*60*60*1000
        res.cookie('username', userInfo.username, { expires: new Date(Date.now() + duration24H) })
        res.redirect('/')
    })

router.get('/logout', (req, res) => {
    //clear cookie
    res.cookie('username', '', {expires: new Date(0)})
    res.redirect("/")
})
router.route('/profile')
    .get( (req, res) => EventController.index(req,res))




//Middleware to intercept requests and redirect to the login page if the user is not logged-in
router.use( (req, res, next) => {
    if (!req.cookies.username) {
        res.redirect("/login")
    }
    else {
        const username = req.cookies.username
        console.log("isAuthenticated.username", username)

        //Allows accessing username variable from handlebars template
        res.locals.username = username
        return next()
    }
})

module.exports = router

//Middleware to intercept requests and redirect to the login page if the user is not logged-in. Only apllies to /students and /heroes
function isAuthenticated(req, res, next) {
     const username = req.cookies.username
     console.log("isAuthenticated.username", username)
     if (!username) {
        res.redirect("/login")
     } else {
        return next()
     }
 }