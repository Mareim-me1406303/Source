
class EventRepository {
    constructor() {
        this.fs = require('fs-promise')
    }

    async getEvents() {
        const data = await this.fs.readFile('data/event.json')
        return JSON.parse(data)
    }
}
module.exports = new EventRepository()