const express	   =  require('express')
const bodyParser   =  require('body-parser')
const cookieParser =  require('cookie-parser')
const handlebars   =  require('express-handlebars')

const app= express()

app.use( express.static( __dirname ))
app.use( bodyParser.urlencoded( {extended: true}) )
app.use( bodyParser.json() )
app.use( cookieParser() )
app.engine( 'hbs', handlebars( {defaultLayout: 'main', extname: '.hbs'} ))
app.set('view engine', 'hbs')
app.set('views', __dirname + '/views')
const routes = require('./routes')
app.use('/', routes)
const port = 9090
app.listen(port, () => {
    const host = "localhost"
    console.log(` App is running @ http://${host}:${port}`)
})